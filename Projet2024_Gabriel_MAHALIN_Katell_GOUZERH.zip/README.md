# Projet SimulationTrainJs

Ce projet est une simulation de train en JavaScript. Réalisé par Gabriel Mahalin et Katell Gouzerh

Bonjour, et bienvenue sur le read me de notre simulateur de train !
Ce que nous avons rajouté par rapport à la partie 1 :
Un menu qui permet à l'utilisateur de choisir entre faire la simulation 1, la siulation 2 et une page d'informations
Lorsqu'un train est ajouté sur la simulation il y a un bruit de tchou-tchou
Lorsque deux trains se rencontrent, il y a une explosion sonore et visuelle
Lorsqu'un train tombe dans l'eau, il y a une goutte d'eau visible ainsi qu'un bruit
Il y a une gare en plus, lorsqu'un train passe devant, il s'arrête pendant quelques secondes et on entends le bruit de la gare
Il y a une barrière en plus, et quand les trains arrivent devant, ils font demi-tour
Il y a un rail de croisement en plus, quand deux trains se retrouvent dessus, ils explosent

# Utilisation
Pour ouvrir la partie 2, il faut ouvrir le fichier Main.html

# Sources Pour la partie 2

Universal soundbank (sons)
Picmix (gif explosion)
Gifer (gif goutte d'eau)
Pinterest (gare)
Vecteezy (barriere)
Chat GPT (pour implémenter les gifs)
